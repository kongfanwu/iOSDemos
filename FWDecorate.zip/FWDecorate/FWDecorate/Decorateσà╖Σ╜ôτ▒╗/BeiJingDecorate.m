//
//  BeiJingDecorate.m
//  FWDecorate
//
//  Created by kfw on 2019/9/16.
//  Copyright © 2019 神灯智能. All rights reserved.
//

#import "BeiJingDecorate.h"

@implementation BeiJingDecorate
- (void)run {
    [self.component run];
    NSLog(@"已到北京");
}

@end
