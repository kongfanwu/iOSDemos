package com.example.java.p2pdemo;

import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.VideoView;

import com.storm.smart.core.P2P;
import android.widget.MediaController;

import java.io.File;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        Button startButton = (Button)findViewById(R.id.start);
        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startPlay();
            }
        });

        Button stopButton = (Button)findViewById(R.id.stop);
        stopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopPlay();
            }
        });
    }

    public  void startPlay()
    {
        File appPath = this.getExternalCacheDir();
        P2P.getInstance().init(this,appPath.toString(),appPath.toString());
        int port  = 8888;
        String qstp = "qstp://qkvp/pGp/bmxleqg/qey:XDXZ.s?jp=GGJ&jd=B0TXW1MMEEGM1CMBJDDDGXCTGZMEWAM0AFJ1QCFE&vd=DA0CCDFFQT1WEF1BBC0ABAXDDDGCDZ0F0BCAZED1&lh=MXFJEGZ&fz=BEGEA&pi=DT&pr=T0BXA&pps=A&ppk=A&pyp=MXFJEDJ&blzd=DFMM&pah=DQBFWT0QGXGAGZQ0TDWCWFAJATZG0JXA&ped=pov";
        int ret = P2P.getInstance().startPlay(qstp,appPath.toString(),30*1024*1024,2,1,port);

        VideoView videoView = (VideoView) findViewById(R.id.main_video);
        MediaController  controller = new MediaController(this);//实例化控制器

        /**
         * 网络播放
         */
        videoView.setVideoURI(Uri.parse("http://127.0.0.1:8888"));

        /**
         * 将控制器和播放器进行互相关联
         */
        controller.setMediaPlayer(videoView);
        videoView.setMediaController(controller);


    }

    public void stopPlay()
    {
        P2P.getInstance().stopPlay();
    }

}
