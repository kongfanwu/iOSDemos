package com.storm.smart.core;

import android.content.Context;
import android.os.Build;
import android.text.TextUtils;
import android.util.Log;


import java.util.ArrayList;

public class P2P {


    private static final String BFP2P_APP_NAME = "wl";

    private static final String TAG = "P2PManager";
    private static P2P instance;
    private String libPath;
    private boolean isP2PInited;
    private boolean isP2PVodStarted;
    private boolean isLoadP2PLibrarySuc;
    private ArrayList<P2PDownloadStateListener> listenerList;
    private int errorCode;

    private P2P() {
        listenerList = new ArrayList<P2PDownloadStateListener>();
    }

    public static P2P getInstance() {
        if (instance == null) {
            instance = new P2P();
        }
        return instance;
    }

    public int getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(int errorCode) {
        this.errorCode = errorCode;
    }

    /**
     * 加载P2P的类库
     *
     * @return
     */
    private boolean loadP2PLibrary(Context context) {

        if (isLoadP2PLibrarySuc) {
            return true;
        }

        try {
            System.load( "libbfp2p.so");
            System.load( "libdownloader.so");
            isLoadP2PLibrarySuc = true;
        } catch (Throwable t) {
            isLoadP2PLibrarySuc = false;
            t.printStackTrace();
            Log.e(TAG, "loadP2PLibrary Exception:" + t.getLocalizedMessage());
        }
        return isLoadP2PLibrarySuc;
    }

    public synchronized void addP2pStateListener(P2PDownloadStateListener p2pStateListener) {
        if (listenerList == null) {
            return;
        }
        if (!listenerList.contains(p2pStateListener)) {
            listenerList.add(p2pStateListener);
        }
    }

    public synchronized void removeP2PStateListener(P2PDownloadStateListener p2pStateListener) {
        if (listenerList == null) {
            return;
        }
        if (listenerList.contains(p2pStateListener)) {
            listenerList.remove(p2pStateListener);
        }
    }

    public static String getSystemVersion() {
        return Build.VERSION.SDK_INT + "";
    }

    public synchronized void init(Context context, String path, String cachePath) {
        if (!loadP2PLibrary(context)) {
            return;
        }
        if (isP2PInited) {
            return;
        }
        try {
            String appVerName = "appVersionName";
            String uuid = "uuid";
            int logLevel = P2PLog.LOG_LEVEL_TRACE;
            /**
             * 获取网络状态
             *
             * @param context
             * @return 0 = 没有网络; 1 = 3G/2G; 2 = wifi
             */
            int netStatus = 2;
            String p2pAppName = BFP2P_APP_NAME;
            String systemVersion = getSystemVersion();
            Log.i(TAG, "lzh p2pInit start, path:" + path + ",cachePath:" + cachePath + ",appVerName:" + appVerName + ",p2pAppName:" + p2pAppName +
                    ",logLevel:" + logLevel + ",netStatus:" + netStatus + ",systemVersion:" + systemVersion + ",uuid:" + uuid);

            int result = p2pInit(path,
                    cachePath,
                    appVerName,
                    p2pAppName,
                    logLevel,
                    netStatus,
                    systemVersion,
                    uuid);
            if (result == 0) {
                isP2PInited = true;
                Log.i(TAG, "lzh p2pInit succeed, result:" + result);
            } else {
                Log.e(TAG, "lzh p2pInit failed, result:" + result);
            }
        } catch (Throwable t) {
            t.printStackTrace();
            Log.e(TAG, "lzh p2pInit Exception:" + t.getLocalizedMessage());
        }
    }

    public synchronized void uninit() {
        if (!isP2PInited) {
            return;
        }
        try {
            Log.i(TAG, "lzh p2pUnInit start");
            int result = p2pUninit();
            if (result == 0) {
                Log.i(TAG, "lzh p2pUnInit succeed, result:" + result);
            } else {
                Log.e(TAG, "lzh p2pUninit Failed, result:" + result);
            }
        } catch (Throwable t) {
            t.printStackTrace();
            Log.e(TAG, "lzh p2pUninit Exception:" + t.getLocalizedMessage());
        }
        isP2PInited = false;
    }

    private native String p2pGetVersion();

    public String getVersion() {
        String version = "1.0";
        if (!isP2PInited) {
            return version;
        }
        try {
            Log.i(TAG, "lzh p2pGetVersion start");
            version = p2pGetVersion();
            Log.i(TAG, "lzh p2pGetVersion end, result:" + version);
        } catch (Throwable t) {
            t.printStackTrace();
            Log.e(TAG, "lzh p2pGetVersion Exception:" + t.getLocalizedMessage());
        }
        return version;
    }

    private native long p2pGetSystemUptimeMillis();

    public long getSystemUptimeMillis() {
        long systemUptimeMillis = -1;
        if (!isP2PInited) {
            return -1;
        }
        try {
            systemUptimeMillis = p2pGetSystemUptimeMillis();
        } catch (Throwable t) {
            t.printStackTrace();
            Log.e(TAG, "lzh p2pGetSystemUptimeMillis Exception:" + t.getLocalizedMessage());
        }
        return systemUptimeMillis;
    }

    /**
     *
     * @param path
     * @param cachePath
     * @param appVersion
     * @param appMame
     * @param logLevel
     * @param netStatus
     * @param osVersion
     * @param uuid
     * @return
     */
    private native int p2pInit(String path, String cachePath, String appVersion, String appMame, int logLevel, int netStatus, String osVersion,String uuid);

    /**
     * P2P反初始化
     *
     * @return
     */
    private native int p2pUninit();

    /**
     * 避免直接调用P2P Native 方法;
     *
     * @param netStatus
     */
    public void setNetStatus(int netStatus) {
        if (!isP2PInited) {
            return;
        }
        try {
            Log.i(TAG, "lzh p2pSetNetStatus start, netStatus:" + netStatus);
            int result = p2pSetNetStatus(netStatus);
            if (result == 0) {
                Log.i(TAG, "lzh p2pSetNetStatus succeed, netStatus:" + netStatus + ",result:" + result);
            } else {
                Log.e(TAG, "lzh p2pSetNetStatus failed, netStatus:" + netStatus + ",result:" + result);
            }
        } catch (Throwable t) {
            t.printStackTrace();
            Log.e(TAG, "lzh p2pSetNetStatus Exception:" + t.getLocalizedMessage());
        }
    }

    /**
     * 设置网络状态
     *
     * @param net_status
     * @return
     */
    private native int p2pSetNetStatus(int net_status);


    /**
     * 启动一个p2p点播任务
     *
     * @param url            :下载的Url
     * @param path           :保存的路径
     * @param romfreesize    : SD卡剩余存储空间，
     * @param usr_cache_type : 0：分段文件；1：单一文件 2:内存缓存。-1：表示该参数无效。这个参数优先于空间大小来判断播放缓存类型
     * @param bUseSever    ;0 表示纯下载 如果是0的话端口号无用 1表示启动server,port 为服务的端口号
     * @param port          ; port 表示server 启动的端口号
     * 启动成功后，视频的播放地址为 http://127.0.0.1:port
     * @return 点播任务Id
     */
    public int startPlay(String url, String path, double romfreesize, int usr_cache_type,int bUseSever,int port) {
        if (TextUtils.isEmpty(url)) {
            return -1;
        }
        if (!isP2PInited) {
            return -1;
        }
        if (isP2PVodStarted) {
            stopPlay();
            Log.e(TAG, "Repeated startPlay, forgot to stopPlay");
        }
        try {
            Log.i(TAG, "lzh p2pStartPlay start, url:" + url);
            int vodTaskId = p2pStartPlay(url, path, romfreesize, 30 * 1024 * 1024, usr_cache_type, bUseSever,port);
            if (vodTaskId > 0) {
                isP2PVodStarted = true;
                Log.i(TAG, "lzh p2pStartPlay succeed, url:" + url + ",result:" + vodTaskId);
            } else {
                Log.e(TAG, "lzh p2pStartPlay failed, url:" + url + ",result:" + vodTaskId);
            }
            return vodTaskId;
        } catch (Throwable t) {
            t.printStackTrace();
            Log.e(TAG, "lzh p2pStartPlay Exception:" + t.getLocalizedMessage());
        }
        return -1;
    }

    /**
     * 启动一个p2p任务
     *
     * @param url            :下载的Url
     * @param path           :保存的路径
     * @param romfreesize    : SD卡剩余存储空间，
     * @param ramfreesize    : 内存剩余空间
     * @param usr_cache_type : 0：文件缓存 (分段文件)；1:文件缓存 (单一文件) 2：内存缓存。-1：表示该参数无效。这个参数优先于空间大小来判断播放缓存类型
     * @param bUseServer     : 0：之前模式；1：表示支持系统播放器播放
     * @return
     */
    private native int p2pStartPlay(String url, String path, double romfreesize, double ramfreesize,
                                   int usr_cache_type, int bUseServer,int port);

    public void stopPlay() {
        if (!isP2PInited) {
            return;
        }
        try {
            Log.i(TAG, "lzh p2pStopPlay start");
            int result = p2pStopPlay();
            if (result == 0) {
                isP2PVodStarted = false;
                Log.i(TAG, "lzh p2pStopPlay succeed, result:" + result);
            } else {
                Log.e(TAG, "lzh p2pStopPlay failed, result:" + result);
            }
        } catch (Throwable t) {
            t.printStackTrace();
            Log.e(TAG, "lzh p2pStopPlay Exception:" + t.getLocalizedMessage());
        }
    }

    /**
     * 停止播放
     *
     * @return
     */
    private native int p2pStopPlay();

    public int startDownload(String url, String path) {
        if (TextUtils.isEmpty(url)) {
            return -1;
        }
        if (!isP2PInited) {
            return -1;
        }
        try {
            Log.i(TAG, "lzh p2pStartDownload start, url:" + url + ",path:" + path);
            int result = p2pStartDownload(url, path);
            if (result > 0) {
                Log.i(TAG, "lzh p2pStartDownload succeed, url:" + url + ",path:" + path + ",result:" + result);
                return result;
            }
            Log.e(TAG, "lzh p2pStartDownload failed, url:" + url + ",path:" + path + ",result:" + result);
        } catch (Throwable t) {
            t.printStackTrace();
            Log.e(TAG, "lzh p2pStartDownload Exception:" + t.getLocalizedMessage());
        }
        return -1;
    }

    /**
     * 開始下載
     *
     * @param url  : 下載url路徑
     * @param path : 保存的路徑
     * @return
     */
    private native int p2pStartDownload(String url, String path);

    public boolean stopDownload(int id) {
        if (id < 0) {
            return false;
        }
        if (!isP2PInited) {
            return false;
        }
        try {
            Log.i(TAG, "lzh p2pStopDownload start, id:" + id);
            int result = p2pStopDownload(id);
            if (result == 0) {
                Log.i(TAG, "lzh p2pStopDownload succeed, id:" + id + ",result:" + result);
                return true;
            }
            Log.e(TAG, "lzh p2pStopDownload failed, id:" + id + ",result:" + result);
        } catch (Throwable t) {
            t.printStackTrace();
            Log.e(TAG, "lzh p2pStopDownload Exception:" + t.getLocalizedMessage());
        }
        return false;
    }

    /**
     * 停止下載
     *
     * @param id :唯一标识;
     * @return 0 成功 负数 :失败
     */
    private native int p2pStopDownload(int id);

    public void clearDownload(String url) {
        if (TextUtils.isEmpty(url)) {
            return;
        }
        if (!isP2PInited) {
            return;
        }
        try {
            Log.i(TAG, "lzh p2pClearDownload start, url:" + url);
            int result = p2pClearDownload(url);
            if (result == 0) {
                Log.i(TAG, "lzh p2pClearDownload succeed, url:" + url + ",result:" + result);
                return;
            }
            Log.e(TAG, "lzh p2pClearDownload failed, url:" + url + ",result:" + result);
        } catch (Throwable t) {
            t.printStackTrace();
            Log.e(TAG, "lzh p2pClearDownload Exception:" + t.getLocalizedMessage());
        }
    }

    /**
     * 清除一个下载任务
     *
     * @param url :下载的唯一标识
     * @return
     */
    private native int p2pClearDownload(String url);

    public void speedLimOpen(int id) {
        if (id < 0) {
            return;
        }
        if (!isP2PInited) {
            return;
        }
        try {
            Log.i(TAG, "lzh p2pSpeedLimOpen start, id:" + id);
            int result = p2pSpeedLimOpen(id);
            if (result == 0) {
                Log.i(TAG, "lzh p2pSpeedLimOpen succeed, id:" + id + ",result:" + result);
                return;
            }
            Log.e(TAG, "lzh p2pSpeedLimOpen failed, id:" + id + ",result:" + result);
        } catch (Throwable t) {
            t.printStackTrace();
            Log.e(TAG, "lzh p2pSpeedLimOpen Exception:" + t.getLocalizedMessage());
        }
    }

    /**
     * 对下载任务进行限速，目前底层只是将下载任务停止
     *
     * @param id :下载的唯一标识
     * @return
     */
    private native int p2pSpeedLimOpen(int id);

    public void speedLimClose(int id) {
        if (id < 0) {
            return;
        }
        if (!isP2PInited) {
            return;
        }
        try {
            Log.i(TAG, "lzh p2pSpeedLimClose start, id:" + id);
            int result = p2pSpeedLimClose(id);
            if (result == 0) {
                Log.i(TAG, "lzh p2pSpeedLimClose succeed, id:" + id + ",result:" + result);
                return;
            }
            Log.e(TAG, "lzh p2pSpeedLimClose failed, id:" + id + ",result:" + result);
        } catch (Throwable t) {
            t.printStackTrace();
            Log.e(TAG, "lzh p2pSpeedLimClose Exception:" + t.getLocalizedMessage());
        }
    }

    /**
     * 结束限速
     *
     * @param id
     * @return
     */
    private native int p2pSpeedLimClose(int id);

    public int getDownloadSize(int task_id) {
        if (task_id < 0) {
            return 0;
        }
        if (!isP2PInited) {
            return 0;
        }
        try {
            return p2pGetDownloadSize(task_id);
        } catch (Throwable t) {
            t.printStackTrace();
            Log.e(TAG, "lzh p2pGetDownloadSize Exception:" + t.getLocalizedMessage());
        }
        return 0;
    }

    /**
     * 获取已经下载长度
     *
     * @return
     */
    private native int p2pGetDownloadSize(int task_id);

    public int getDownloadSizeNoTask(String url) {
        if (TextUtils.isEmpty(url)) {
            return 0;
        }
        if (!isP2PInited) {
            return 0;
        }
        try {
            return p2pGetDownloadSizeNoTask(url);
        } catch (Throwable t) {
            t.printStackTrace();
            Log.e(TAG, "lzh p2pGetDownloadSizeNoTask Exception:" + t.getLocalizedMessage());
        }
        return 0;
    }

    /**
     * 获取已经下载长度，在任务启动时调用
     *
     * @param url
     * @return
     */
    private native int p2pGetDownloadSizeNoTask(String url);

    public int getDownloadSpeed(int id) {
        if (id < 0) {
            return 0;
        }
        if (!isP2PInited) {
            return 0;
        }
        try {
            return p2pGetDownloadSpeed(id);
        } catch (Throwable t) {
            t.printStackTrace();
            Log.e(TAG, "lzh p2pGetDownloadSpeed Exception:" + t.getLocalizedMessage());
        }
        return 0;
    }

    /**
     * 获得任务的已下载数据速度
     *
     * @param id
     * @return
     */
    private native int p2pGetDownloadSpeed(int id);

    public int getFileSize(String url) {
        if (TextUtils.isEmpty(url)) {
            return 0;
        }
        if (!isP2PInited) {
            return 0;
        }
        try {
            return p2pGetFileSize(url);
        } catch (Throwable t) {
            t.printStackTrace();
            Log.e(TAG, "lzh p2pGetFileSize Exception:" + t.getLocalizedMessage());
        }
        return 0;
    }

    /**
     * 获取操作文件的长度
     *
     * @param url
     * @return
     */
    private native int p2pGetFileSize(String url);

    public void setPlayPos(int pos_ms) {
        if (pos_ms < 0) {
            return;
        }
        if (!isP2PInited) {
            return;
        }
        try {
            int result = p2pSetPlayPos(pos_ms);
            if (result != 0) {
                Log.e(TAG, "lzh p2pSetPlayPos failed, pos:" + pos_ms + ",result:" +result);
            }
        } catch (Throwable t) {
            t.printStackTrace();
            Log.e(TAG, "lzh p2pSetPlayPos Exception:" + t.getLocalizedMessage());
        }
    }

    /**
     * 设置播放时间 需要外层不断调用，以设置播放点。该播放点将会影响到p2p紧急区的计算。调用频率暂定和IPAD项目相同：1秒调用一次
     *
     * @param pos_ms 播放时间点，单位：毫秒。
     * @return 0：成功；非0：失败。
     */
    private native int p2pSetPlayPos(int pos_ms);

    public int getTimeCanPlay(int pos_ms) {
        if (pos_ms < 0) {
            return 0;
        }
        if (!isP2PInited) {
            return 0;
        }
        try {
            return p2pGetTimeCanPlay(pos_ms);
        } catch (Throwable t) {
            t.printStackTrace();
            Log.e(TAG, "lzh p2pGetTimeCanPlay Exception:" + t.getLocalizedMessage());
        }
        return 0;
    }

    /**
     * 取得缓存中可以播放的时间(播放第二进度条使用)
     *
     * @param pos_ms
     * @return
     */
    private native int p2pGetTimeCanPlay(int pos_ms);

    public String p2pCountGetPlayTimeInfo() {
        if (!isP2PInited) {
            return "";
        }
        try {
            String playTimeInfo = p2pGetPlayTimeInfo();
            if (!TextUtils.isEmpty(playTimeInfo)) {
                Log.i(TAG, "lzh p2pGetPlayTimeInfo succeed");
            } else {
                Log.e(TAG, "lzh p2pGetPlayTimeInfo failed");
            }
            return playTimeInfo;
        } catch (Throwable t) {
            t.printStackTrace();
            Log.e(TAG, "lzh p2pGetPlayTimeInfo Exception:" + t.getLocalizedMessage());
        }
        return "";
    }

    /**
     * 取得p2p任务开始成功或失败，及任务启动时间
     * 返回json串
     *
     * @return
     */
    private native String p2pGetPlayTimeInfo();

    /**
     * 获取gcid
     *
     * @param url
     * @return
     */
    private native String p2pQstpGetGcid(String qstp);

    public String getGcidByQstp(String qstp) {
        if (TextUtils.isEmpty(qstp)) {
            return "";
        }
        if (!isP2PInited) {
            return "";
        }
        String gcid = "";
        try {
            Log.i(TAG, "lzh p2pQstpGetGcid start, qstp:" + qstp);
            gcid = p2pQstpGetGcid(qstp);
            Log.i(TAG, "lzh p2pQstpGetGcid end, gcid:" + gcid + ",qstp:" + qstp);
        } catch (Throwable t) {
            t.printStackTrace();
            Log.e(TAG, "lzh p2pQstpGetGcid Exception:" + t.getLocalizedMessage());
        }
        return gcid;
    }

    /**
     * 增加新的p2p缓存路径
     * 缺省情况下，p2p使用start_up指定的缓存路径为当前缓存路径，如果需要增加更多缓存路径
     * 使用该方法添加。底层保证路径不重复
     * 该方法适用于文件型缓存，如果任务为内存型缓存，则直接在内存中创建缓存，与该逻辑无关
     *
     * @param path
     */
    private native void p2pAddPath(String path);

    /**
     * 指定当前使用的p2p缓存路径
     * 缺省情况下，p2p使用start_up指定的缓存路径为当前缓存路径，如果希望设为其他缓存路径，
     * 请先添加p2pAddPath，然后再p2pSetCurPath
     * 该方法适用于文件型缓存，如果任务为内存型缓存，则直接在内存中创建缓存，与该逻辑无关
     *
     * @param path
     * @return 0 表示成功，非0失败
     */
    private native int p2pSetCurPath(String path);

    private native int firstBufferComplete(int taskId, int have_ad, int have_interrupt);

    // 直播才需要调用
    public boolean liveFirstBufferComplete(int liveTaskId, int have_ad, int have_interrupt) {
        if (liveTaskId <= 0) {
            return false;
        }
        if (!isP2PInited) {
            return false;
        }
        try {
            Log.i(TAG, "lzh firstBufferComplete start, taskId:" + liveTaskId + ",have_ad:" + have_ad + ",have_interrupt:" + have_interrupt);
            int result = firstBufferComplete(liveTaskId, have_ad, have_interrupt);
            if (result == 0) {
                Log.i(TAG, "lzh firstBufferComplete succeed, taskId:" + liveTaskId + ",result:" + result);
                return true;
            }
            Log.e(TAG, "lzh firstBufferComplete failed, taskId:" + liveTaskId + ",result:" + result);
        } catch (Throwable t) {
            t.printStackTrace();
            Log.e(TAG, "lzh firstBufferComplete Exception:" + t.getLocalizedMessage());
        }
        return false;
    }


    // 返回值
    // 0:264
    // 1:265
    // -1:解析url失败
    private native int getVideoCode(String qstp);

    public int getVideoCodeByQstp(String qstp) {
        if (TextUtils.isEmpty(qstp)) {
            return -1;
        }
        if (!isP2PInited) {
            return -1;
        }
        int result = -1;
        try {
            Log.i(TAG, "lzh getVideoCode start, qstp:" + qstp);
            result = getVideoCode(qstp);
            if (result >= 0) {
                Log.i(TAG, "lzh getVideoCode succeed, result:" + result + ",qstp:" + qstp);
            } else {
                Log.e(TAG, "lzh getVideoCode failed, result:" + result + ",qstp:" + qstp);
            }
        } catch (Throwable t) {
            t.printStackTrace();
            Log.e(TAG, "lzh getVideoCode Exception:" + t.getLocalizedMessage());
        }
        return result;
    }

    public void addP2PCachePath(String path) {
        if (TextUtils.isEmpty(path)) {
            return;
        }
        if (!isP2PInited) {
            return;
        }
        try {
            p2pAddPath(path);
        } catch (Throwable t) {
            t.printStackTrace();
            Log.e(TAG, "lzh p2pAddPath Exception:" + t.getLocalizedMessage());
        }
    }

    public int setP2PCurrentCachePath(String path) {
        if (TextUtils.isEmpty(path)) {
            return -1;
        }
        if (!isP2PInited) {
            return -1;
        }
        try {
            return p2pSetCurPath(path);
        } catch (Throwable t) {
            t.printStackTrace();
            Log.e(TAG, "lzh p2pSetCurPath Exception:" + t.getLocalizedMessage());
        }
        return -1;
    }

    public int p2pLiveTaskCreate(String url, int cacheSize, int flags) {
        if (TextUtils.isEmpty(url)) {
            return -1;
        }
        if (!isP2PInited) {
            return -1;
        }
        try {
            Log.i(TAG, "lzh liveTaskCreate start, taskUrl:" + url);
            int result = liveTaskCreate(url, cacheSize, flags, this);
            if (result > 0) {
                Log.i(TAG, "lzh liveTaskCreate succeed, taskUrl:" + url + ",result:" + result);
            } else {
                Log.e(TAG, "lzh liveTaskCreate failed, url:" + url + ",result:" + result);
            }
            return result;
        } catch (Throwable t) {
            t.printStackTrace();
            Log.e(TAG, "lzh liveTaskCreate Exception:" + t.getLocalizedMessage());
        }
        return -1;
    }

    public int p2pLiveStreamStart(int taskId, int port) {
        if (taskId <= 0 || port <= 0) {
            return -1;
        }
        if (!isP2PInited) {
            return -1;
        }
        try {
            int result = liveStreamStart(taskId, port);
            if (result == 0) {
                Log.i(TAG, "lzh liveStreamStart succeed, taskId:" + taskId + ",port:" + port + ",result:" + result);
            } else {
                Log.e(TAG, "lzh liveStreamStart failed, taskId:" + taskId + ",port:" + port + ",result:" + result);
            }
            return result;
        } catch (Throwable t) {
            t.printStackTrace();
            Log.e(TAG, "lzh liveStreamStart Exception:" + t.getLocalizedMessage());
        }
        return -1;
    }

    public int p2pLiveStreamStop(int taskId) {
        if (taskId <= 0) {
            return -1;
        }
        if (!isP2PInited) {
            return -1;
        }
        try {
            int result = liveStreamStop(taskId);
            if (result == 0) {
                Log.i(TAG, "lzh liveStreamStop succeed, taskId:" + taskId + ",result:" + result);
            } else {
                Log.e(TAG, "lzh liveStreamStop failed, taskId:" + taskId + ",result:" + result);
            }
            return result;
        } catch (Throwable t) {
            t.printStackTrace();
            Log.e(TAG, "lzh liveStreamStop Exception:" + t.getLocalizedMessage());
        }
        return -1;
    }

    public int p2pLiveTaskDestory(int taskId) {
        if (taskId <= 0) {
            return -1;
        }
        if (!isP2PInited) {
            return -1;
        }
        try {
            int result = liveTaskDestory(taskId);
            if (result == 0) {
                Log.i(TAG, "lzh liveTaskDestory succeed, taskId:" + taskId + ",result:" + result);
            } else {
                Log.e(TAG, "lzh liveTaskDestory failed, taskId:" + taskId + ",result:" + result);
            }
            return result;
        } catch (Throwable t) {
            t.printStackTrace();
            Log.e(TAG, "lzh liveTaskDestory Exception:" + t.getLocalizedMessage());
        }
        return -1;
    }

    /**
     * 创建直播任务
     */
    private native int liveTaskCreate(String taskUrl, int cacheSize, int flags, Object obj);

    private native int liveStreamStart(int taskId, int port);

    private native int liveStreamStop(int taskId);

    private native int liveTaskDestory(int taskId);

    public void live_state_callback(int oldStatus, int newStatus, int code) {
        if (listenerList == null) {
            return;
        }
        for (P2PDownloadStateListener listener : listenerList) {
            listener.onP2PLiveCallback(oldStatus, newStatus, code);
        }
    }

    // 底层会回调此方法
    public void p2p_notify(int task_id, int event, int error) {
        errorCode = error;
        Log.d(TAG, "p2p_notify,task_id = " + task_id + " event:" + event + ",error:" + error);
        if (listenerList == null) {
            return;
        }
        switch (event) {
            case P2PEvent.P2P_DL_STATE_COMPLETED:
                Log.d(TAG, "P2P_DL_STATE_COMPLETED task_id = " + task_id);
                for (P2PDownloadStateListener listener : listenerList) {
                    listener.onP2PComplete(this, task_id);
                }
                break;
            case P2PEvent.P2P_DL_STATE_DOWNLOADING:
                Log.d(TAG, "P2P_DL_STATE_DOWNLOADING task_id = " + task_id);
                for (P2PDownloadStateListener listener : listenerList) {
                    listener.onP2PPrepared(this, task_id);
                }
                break;
            case P2PEvent.P2P_DL_STATE_FAIL:
                Log.d(TAG, "P2P_DL_STATE_FAIL task_id = " + task_id);
                for (P2PDownloadStateListener listener : listenerList) {
                    listener.onP2PError(error, this, task_id);
                }
                break;
            case P2PEvent.P2P_DL_STATE_IDLE:
                Log.d(TAG, "P2P_DL_STATE_IDLE task_id = " + task_id);
                for (P2PDownloadStateListener listener : listenerList) {
                    listener.p2pDownloadIdle(task_id);
                }
                break;
            default:
                break;
        }
    }

    public interface P2PEvent {
        int P2P_DL_STATE_IDLE = 0;// (任务空闲状态) 0

        int P2P_DL_STATE_DOWNLOADING = 1;// （任务下载中） 1

        int P2P_DL_STATE_COMPLETED = 2;// （任务下载完成） 2

        int P2P_DL_STATE_FAIL = 3;// （任务失败） 3
    }

    public interface P2PDownloadStateListener {
        public void p2pDownloadIdle(int taskId);

        public void onP2PPrepared(P2P p2p, int taskId);

        public void onP2PComplete(P2P p2p, int taskId);

        public void onP2PError(int what, P2P p2p, int taskId);

        public void onP2PLiveCallback(int oldStatus, int newStatus, int code);
    }

    public interface P2PLog {
        int LOG_LEVEL_TRACE = 0;

        int LOG_LEVEL_DEBUG = 100;

        int LOG_LEVEL_INFO = 200;

        int LOG_LEVEL_WARN = 300;

        int LOG_LEVEL_ERROR = 400;

        int LOG_LEVEL_FATAL = 500;

        int LOG_LEVEL_OFF = 1000;
    }
}
