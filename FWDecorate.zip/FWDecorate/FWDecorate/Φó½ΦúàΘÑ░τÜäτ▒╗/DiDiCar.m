//
//  DiDiCar.m
//  FWDecorate
//
//  Created by kfw on 2019/9/16.
//  Copyright © 2019 神灯智能. All rights reserved.
//

#import "DiDiCar.h"

@implementation DiDiCar
- (void)run {
    NSLog(@"DiDiCar run");
}
@end
