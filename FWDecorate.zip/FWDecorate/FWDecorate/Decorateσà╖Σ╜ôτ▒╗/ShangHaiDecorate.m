//
//  ShangHaiDecorate.m
//  FWDecorate
//
//  Created by kfw on 2019/9/16.
//  Copyright © 2019 神灯智能. All rights reserved.
//

#import "ShangHaiDecorate.h"

@implementation ShangHaiDecorate
- (void)run {
    [self.component run];
    NSLog(@"已到上海");
}
@end
